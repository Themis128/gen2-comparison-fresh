1:"$Sreact.fragment"
2:I[92960,["/_next/static/chunks/1c25bec265e983b3.js","/_next/static/chunks/0e1611d8c9526112.js"],"ViewportBoundary"]
3:I[92960,["/_next/static/chunks/1c25bec265e983b3.js","/_next/static/chunks/0e1611d8c9526112.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"YCcQccTB7cEo0NUjD9JGD","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
