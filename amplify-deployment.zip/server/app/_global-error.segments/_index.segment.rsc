1:"$Sreact.fragment"
2:I[24905,["/_next/static/chunks/1c25bec265e983b3.js","/_next/static/chunks/0e1611d8c9526112.js"],"default"]
3:I[81484,["/_next/static/chunks/1c25bec265e983b3.js","/_next/static/chunks/0e1611d8c9526112.js"],"default"]
0:{"buildId":"YCcQccTB7cEo0NUjD9JGD","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
