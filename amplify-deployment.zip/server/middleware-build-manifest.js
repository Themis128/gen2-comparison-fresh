globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/104d8a574ce1d5d4.js",
    "static/chunks/39e146b12f2293f0.js",
    "static/chunks/1832c5c67d7b2df1.js",
    "static/chunks/9de8f47c16179277.js",
    "static/chunks/turbopack-3a371c20b7ef5c3f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];