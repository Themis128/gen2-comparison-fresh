var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/[root-of-the-server]__4daf3879._.js")
R.c("server/chunks/[root-of-the-server]__dcb2e74a._.js")
R.m(69449)
module.exports=R.m(69449).exports
