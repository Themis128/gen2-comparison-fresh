var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/[root-of-the-server]__61151bc3._.js")
R.c("server/chunks/_2b89bf45._.js")
R.m(69449)
module.exports=R.m(69449).exports
