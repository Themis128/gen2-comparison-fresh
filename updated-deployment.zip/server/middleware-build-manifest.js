globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4b0ecbe1f02b49e1.js",
    "static/chunks/d3b32ed10124c5d3.js",
    "static/chunks/eb14bc0019428dd8.js",
    "static/chunks/bfcf483e9232a5b9.js",
    "static/chunks/6123393fb139f6ea.js",
    "static/chunks/turbopack-e6355f19394ad06e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];