:HL["/_next/static/chunks/f37209bbef530327.css","style"]
:HL["/_next/static/chunks/2473c16c0c2f6b5f.css","style"]
:HL["/_next/static/chunks/9dfccb0f6458781b.css","style"]
:HL["/_next/static/chunks/34957b3abbac0bb8.css","style"]
0:{"buildId":"EKIHrOzlox1fc1r9moQak","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
