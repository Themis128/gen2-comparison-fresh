:HL["/_next/static/chunks/f37209bbef530327.css","style"]
:HL["/_next/static/chunks/2473c16c0c2f6b5f.css","style"]
:HL["/_next/static/chunks/9dfccb0f6458781b.css","style"]
:HL["/_next/static/chunks/34957b3abbac0bb8.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.dbea232f.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.853070df.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"buildId":"EKIHrOzlox1fc1r9moQak","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"auth","paramType":null,"paramKey":"auth","hasRuntimePrefetch":false,"slots":{"children":{"name":"reset-password","paramType":null,"paramKey":"reset-password","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
