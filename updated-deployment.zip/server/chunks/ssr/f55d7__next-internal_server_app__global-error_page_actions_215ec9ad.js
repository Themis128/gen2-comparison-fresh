module.exports=[48322,(a,b,c)=>{}];

//# sourceMappingURL=f55d7__next-internal_server_app__global-error_page_actions_215ec9ad.js.map