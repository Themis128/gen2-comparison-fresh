module.exports=[36625,(a,b,c)=>{}];

//# sourceMappingURL=0ffa5_en2-comparison-fresh__next-internal_server_app_auth_signup_page_actions_7d8107cf.js.map