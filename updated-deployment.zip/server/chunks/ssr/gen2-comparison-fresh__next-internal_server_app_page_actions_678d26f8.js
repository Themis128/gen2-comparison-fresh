module.exports=[64145,(a,b,c)=>{}];

//# sourceMappingURL=gen2-comparison-fresh__next-internal_server_app_page_actions_678d26f8.js.map