module.exports=[54185,(a,b,c)=>{}];

//# sourceMappingURL=f55d7__next-internal_server_app_auth_reset-password_page_actions_51d7a667.js.map