module.exports=[47722,(a,b,c)=>{}];

//# sourceMappingURL=gen2-comparison-fresh__next-internal_server_app_ui-demo_page_actions_8c3c27ef.js.map