module.exports=[15662,(a,b,c)=>{}];

//# sourceMappingURL=f55d7__next-internal_server_app_custom-navigation-demo_page_actions_a0eabc90.js.map