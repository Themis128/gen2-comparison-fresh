module.exports=[48201,(a,b,c)=>{}];

//# sourceMappingURL=gen2-comparison-fresh__next-internal_server_app_admin_page_actions_cde0e9fd.js.map