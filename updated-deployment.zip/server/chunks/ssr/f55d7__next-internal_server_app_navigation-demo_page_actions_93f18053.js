module.exports=[14935,(a,b,c)=>{}];

//# sourceMappingURL=f55d7__next-internal_server_app_navigation-demo_page_actions_93f18053.js.map