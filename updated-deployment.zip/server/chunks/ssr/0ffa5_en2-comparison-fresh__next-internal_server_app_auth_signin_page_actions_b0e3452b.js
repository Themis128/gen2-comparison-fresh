module.exports=[30955,(a,b,c)=>{}];

//# sourceMappingURL=0ffa5_en2-comparison-fresh__next-internal_server_app_auth_signin_page_actions_b0e3452b.js.map