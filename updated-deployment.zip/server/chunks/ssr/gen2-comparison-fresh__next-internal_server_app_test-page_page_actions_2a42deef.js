module.exports=[84240,(a,b,c)=>{}];

//# sourceMappingURL=gen2-comparison-fresh__next-internal_server_app_test-page_page_actions_2a42deef.js.map