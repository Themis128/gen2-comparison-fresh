module.exports=[96694,(a,b,c)=>{}];

//# sourceMappingURL=f55d7__next-internal_server_app_auth_forgot-password_page_actions_d262d819.js.map