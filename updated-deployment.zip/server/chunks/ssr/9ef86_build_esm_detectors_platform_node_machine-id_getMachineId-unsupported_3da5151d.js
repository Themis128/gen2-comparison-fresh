module.exports=[13284,a=>{"use strict";var b=a.i(84151);async function c(){b.diag.debug("could not read machine-id: unsupported platform")}a.s(["getMachineId",()=>c])}];

//# sourceMappingURL=9ef86_build_esm_detectors_platform_node_machine-id_getMachineId-unsupported_3da5151d.js.map