module.exports=[34160,e=>{"use strict";var d=e.i(43170);async function t(){d.diag.debug("could not read machine-id: unsupported platform")}e.s(["getMachineId",()=>t])}];

//# sourceMappingURL=9ef86_build_esm_detectors_platform_node_machine-id_getMachineId-unsupported_b1cfddda.js.map